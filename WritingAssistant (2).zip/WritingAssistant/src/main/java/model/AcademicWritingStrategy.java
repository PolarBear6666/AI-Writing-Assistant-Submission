package model;


public class AcademicWritingStrategy implements WritingStrategy {

    @Override
    public String getSystemPrompt() {
        return "You are an objective, academic researcher. Your responses must be structured with clear headings, use formal vocabulary, and cite external sources where appropriate.";
    }

    @Override
    public String getName() {
        return "Academic Research";
    }

    @Override
    public int getMaxTokens() {
        return 700;
    }

    /**
     * This method is crucial for the JComboBox in MainFrame to display the name correctly.
     */
    @Override
    public String toString() {
        return getName();
    }
}