package model;

/**
 * Concrete implementation of WritingStrategy for generating imaginative and creative content.
 */
public class CreativeWritingStrategy implements WritingStrategy {

    @Override
    public String getSystemPrompt() {
        return "You are an imaginative and poetic storyteller. Respond with vivid detail, evocative language, and a narrative style. Never use bullet points.";
    }

    @Override
    public String getName() {
        return "Creative Storytelling";
    }

    @Override
    public int getMaxTokens() {
        return 800; // Allows for longer, more descriptive output
    }

    /**
     * This method is crucial for the JComboBox in MainFrame to display the name correctly.
     */
    @Override
    public String toString() {
        return getName();
    }
}