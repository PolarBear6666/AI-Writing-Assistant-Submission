package view;

import controller.MainController;
import model.CreativeWritingStrategy;
import model.ProfessionalWritingStrategy;
import model.WritingStrategy;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * The View in the MVC pattern. Handles displaying data and capturing user input.
 * It uses a simple layout to arrange the components.
 */
public class MainFrame extends JFrame {
    private final MainController controller;
    private final JTextArea inputArea = new JTextArea(10, 45);
    private final JTextArea resultArea = new JTextArea(10, 45);
    private final JLabel statusLabel = new JLabel("Application Starting...");
    private final JComboBox<WritingStrategy> strategySelector;

    // All available strategies
    private final List<WritingStrategy> availableStrategies = List.of(
            new CreativeWritingStrategy(),
            new ProfessionalWritingStrategy(),
            new model.AcademicWritingStrategy() // Assuming you create this later
    );

    public MainFrame(MainController controller) {
        this.controller = controller;

        setTitle("AI Writing Assistant (MVC + Strategy)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // --- Component Setup ---

        // Strategy Selector
        this.strategySelector = new JComboBox<>(availableStrategies.toArray(new WritingStrategy[0]));
        // Uses the Strategy's toString() or getName() method for display
        this.strategySelector.setRenderer(new StrategyRenderer());
        this.strategySelector.setSelectedItem(controller.getCurrentStrategy());

        // Input Area Setup
        inputArea.setLineWrap(true);
        inputArea.setBorder(BorderFactory.createTitledBorder("Your Input Prompt:"));

        // Result Area Setup
        resultArea.setLineWrap(true);
        resultArea.setEditable(false);
        resultArea.setBorder(BorderFactory.createTitledBorder("AI Generated Output:"));

        // Buttons
        JButton generateButton = new JButton("Generate Text");
        JButton saveButton = new JButton("Save Session"); // Removed (TODO)
        JButton loadButton = new JButton("Load Session"); // Removed (TODO)

        // --- Event Handling ---

        // Action: Generate Button (Delegates to Controller)
        generateButton.addActionListener(e -> {
            // Check for empty input
            if (inputArea.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a prompt.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            controller.generateText(inputArea.getText());
        });

        // **FIX HERE: Action for Save Session Button (Delegates to Controller)**
        saveButton.addActionListener(e -> controller.saveSession());

        // **FIX HERE: Action for Load Session Button (Delegates to Controller)**
        loadButton.addActionListener(e -> controller.loadSession());


        // Action: Strategy Selector (Delegates to Controller)
        strategySelector.addActionListener(e -> {
            WritingStrategy selected = (WritingStrategy) strategySelector.getSelectedItem();
            if (selected != null) {
                controller.setStrategy(selected);
            }
        });

        // --- Layout Assembly ---

        // Top Panel: Mode Selector and Control Buttons
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.add(new JLabel("Mode:"));
        controlPanel.add(strategySelector);
        controlPanel.add(generateButton);
        controlPanel.add(saveButton);
        controlPanel.add(loadButton);

        // Center Panel: Input and Output Areas
        JPanel textPanel = new JPanel(new GridLayout(1, 2, 10, 10)); // 1 Row, 2 Columns
        textPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        textPanel.add(new JScrollPane(inputArea));
        textPanel.add(new JScrollPane(resultArea));

        // Status Bar
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusLabel.setFont(statusLabel.getFont().deriveFont(Font.BOLD));

        // Main Frame Layout
        setLayout(new BorderLayout());
        add(controlPanel, BorderLayout.NORTH);
        add(textPanel, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        pack(); // Sizes the frame based on component sizes
        setLocationRelativeTo(null); // Center the window
    }

    // --- Public Methods for Controller Access ---

    public void setResultText(String text) {
        resultArea.setText(text);
    }

    // **NEW METHOD FIX #1: Allows Controller to set the input text box (for Load Session)**
    public void setInputText(String text) {
        inputArea.setText(text);
    }

    public void setStatus(String status) {
        statusLabel.setText(status);
    }

    // Custom ListCellRenderer to ensure the JComboBox displays the Strategy Name correctly
    private class StrategyRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof WritingStrategy) {
                setText(((WritingStrategy) value).getName());
            }
            return this;
        }
    }
}