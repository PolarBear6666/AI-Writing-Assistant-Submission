package controller;

import service.OpenAIService;
import model.APIClient;
import model.WritingStrategy;
import model.WritingSession;
import view.MainFrame;
import javax.swing.SwingUtilities;
import javax.swing.JFileChooser; // Import for file dialog
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.*; // Import for Serialization (Object streams, File streams)
import java.util.List;

/**
 * The Controller in the MVC pattern. Handles user actions, communicates
 * with the Service layer, and updates the View.
 */
public class MainController {

    private MainFrame view;
    private final OpenAIService service;
    private WritingStrategy currentStrategy;

    private WritingSession session = new WritingSession();

    public MainController(String apiKey) {
        // Initialize the Singleton instance and get the service
        this.service = APIClient.getInstance(apiKey).getOpenAIService();

        // Set a default strategy upon startup
        this.currentStrategy = new model.CreativeWritingStrategy();
    }

    // Setter for the View (used right after the View is constructed)
    public void setView(MainFrame view) {
        this.view = view;
        if (view != null) {
            view.setStatus("Ready. Strategy: " + currentStrategy.getName());
        }
    }

    /**
     * Handles the 'Generate' button click. Triggers the asynchronous API call.
     * @param userInput The text provided by the user.
     */
    public void generateText(String userInput) {
        if (view == null) return;

        view.setStatus("Generating response using " + currentStrategy.getName() + "...");
        view.setResultText("..."); // Clear previous result

        // 1. Call the asynchronous service method
        service.generateTextAsync(userInput, currentStrategy)
                .thenAccept(result -> {
                    // 2. IMPORTANT: Update Swing components on the Event Dispatch Thread (EDT)
                    SwingUtilities.invokeLater(() -> {
                        view.setResultText(result);
                        view.setStatus("Generation Complete.");

                        // **UPDATE HERE: Save the exchange to the WritingSession model**
                        session.addExchange(userInput, result);
                    });
                })
                .exceptionally(e -> {
                    // 3. Handle exceptions from the async chain
                    String errorMessage = e.getCause() != null ? e.getCause().getMessage() : e.getMessage();
                    SwingUtilities.invokeLater(() -> {
                        view.setResultText("--- ERROR ---");
                        view.setStatus("FAILED: " + errorMessage);
                    });
                    return null; // Completes the exceptionally stage
                });
    }

    /**
     * Updates the currently active strategy when the user selects a different mode.
     */
    public void setStrategy(WritingStrategy newStrategy) {
        this.currentStrategy = newStrategy;
        if (view != null) {
            view.setStatus("Strategy switched to: " + newStrategy.getName());
        }
    }

    // Getter used by the View to populate the strategy selector
    public WritingStrategy getCurrentStrategy() {
        return currentStrategy;
    }



    /**
     * Handles the 'Save Session' button click. Uses Object Serialization.
     */
    public void saveSession() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Writing Session");
        // Filter to only allow .session files
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Writing Session Files (*.session)", "session");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            // Ensure the file has the correct extension
            if (!fileToSave.getName().toLowerCase().endsWith(".session")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".session");
            }

            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileToSave))) {
                oos.writeObject(session); // Serialize the whole session object to the file
                view.setStatus("Session saved successfully to: " + fileToSave.getAbsolutePath());
            } catch (IOException ex) {
                view.setStatus("ERROR: Could not save session.");
                JOptionPane.showMessageDialog(view, "Error saving session: " + ex.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Handles the 'Load Session' button click. Uses Object Deserialization.
     */
    public void loadSession() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Load Writing Session");
        // Filter to only allow .session files
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Writing Session Files (*.session)", "session");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showOpenDialog(view);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToLoad = fileChooser.getSelectedFile();

            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileToLoad))) {
                WritingSession loadedSession = (WritingSession) ois.readObject();
                this.session = loadedSession; // Replace the current session with the loaded one

                // Update the view with the last known state
                if (!session.getExchanges().isEmpty()) {
                    // Get the last exchange to display it
                    WritingSession.Exchange lastExchange = session.getLastExchange();
                    // Assumes the view has setInputText and setResultText methods
                    view.setInputText(lastExchange.getInput());
                    view.setResultText(lastExchange.getOutput());
                } else {
                    view.setInputText("");
                    view.setResultText("");
                }
                view.setStatus("Session loaded successfully from: " + fileToLoad.getAbsolutePath());
            } catch (IOException | ClassNotFoundException ex) {
                view.setStatus("ERROR: Could not load session.");
                JOptionPane.showMessageDialog(view, "Error loading session: " + ex.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}