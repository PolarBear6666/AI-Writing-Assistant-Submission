package service;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/** Represents the JSON structure for the request sent to the OpenAI API. */
public class OpenAIRequest {
    public String model;
    public List<Message> messages;

    @JsonProperty("max_tokens")
    public int maxTokens;

    public OpenAIRequest(String model, List<Message> messages, int maxTokens) {
        this.model = model;
        this.messages = messages;
        this.maxTokens = maxTokens;
    }

    /** Inner class for a single message in the conversation. */
    public static class Message {
        public String role; // e.g., "system", "user"
        public String content;

        public Message(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }
}