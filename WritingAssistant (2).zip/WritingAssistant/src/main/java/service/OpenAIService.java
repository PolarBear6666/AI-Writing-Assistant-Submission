package service;

import model.WritingStrategy;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class OpenAIService {
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String apiKey;

    public OpenAIService(String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * Sends an asynchronous request to the OpenAI API using the selected strategy.
     * @param prompt The user's input text to be written about.
     * @param strategy The selected writing strategy (determines role/tokens).
     * @return A CompletableFuture<String> containing the generated text or an error message.
     */
    public CompletableFuture<String> generateTextAsync(String prompt, WritingStrategy strategy) {
        try {
            // 1. Build the list of messages, including the system role instruction
            List<OpenAIRequest.Message> messages = List.of(
                    new OpenAIRequest.Message("system", strategy.getSystemPrompt()),
                    new OpenAIRequest.Message("user", prompt)
            );

            // 2. Create the Request Object
            OpenAIRequest requestBody = new OpenAIRequest("gpt-3.5-turbo", messages, strategy.getMaxTokens());

            // Convert Request Object to JSON string
            String jsonBody = objectMapper.writeValueAsString(requestBody);

            // 3. Build the HTTP Request
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .build();

            // 4. Send the request asynchronously
            return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenApply(response -> {
                        // 5. Handle the response and errors
                        if (response.statusCode() != 200) {
                            // Error Handling: Check for rate limits, bad key, etc.
                            System.err.println("API Error Response: " + response.body());
                            throw new RuntimeException("API Request Failed with Status " + response.statusCode() +
                                    ". Check console for details.");
                        }

                        // 6. Parse the JSON response
                        try {
                            OpenAIResponse apiResponse = objectMapper.readValue(response.body(), OpenAIResponse.class);
                            // Safely extract the content
                            return apiResponse.choices.get(0).message.content;
                        } catch (Exception e) {
                            // Error Handling: Catch JSON parsing issues
                            throw new RuntimeException("Failed to parse API response: " + e.getMessage());
                        }
                    })
                    .exceptionally(e -> {
                        // Final Error Handling for network issues or unhandled exceptions
                        return "Network/Async Error: " + e.getCause().getMessage();
                    });

        } catch (Exception e) {
            // Error Handling: Catch synchronous issues (e.g., Jackson JSON serialization failure)
            return CompletableFuture.completedFuture("Setup Error: Could not prepare request. " + e.getMessage());
        }
    }
}