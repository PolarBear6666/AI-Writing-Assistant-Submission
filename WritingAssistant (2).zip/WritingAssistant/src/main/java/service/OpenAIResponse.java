package service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

// FIX 1: Fixes top-level fields like "id", "object", etc.
@JsonIgnoreProperties(ignoreUnknown = true)
public class OpenAIResponse {

    public List<Choice> choices;

    /**
     * Maps the 'choices' array from the API response.
     */
    // FIX 2: Fixes fields in the Choice object like "index", "finish_reason", etc.
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Choice {
        public Message message;
    }

    /**
     * Maps the 'message' object inside 'choice' to extract the content.
     */
    // FIX 3 (NEW FIX): Fixes fields in the Message object like "refusal"!
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Message {
        public String role; // e.g., "assistant"
        public String content; // The actual generated text
    }
}