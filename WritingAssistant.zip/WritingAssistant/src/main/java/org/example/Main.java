package org.example;


import controller.MainController;
import view.MainFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // 1. Get API Key SECURELY (from environment variable)
        String apiKey = System.getenv("OPENAI_API_KEY");

        if (apiKey == null || apiKey.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "Error: OPENAI_API_KEY environment variable not set. " +
                            "Please set it in your IntelliJ Run Configuration (Environment Variables).",
                    "Configuration Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 2. Start the Swing UI on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            try {
                // 3. Instantiate MVC components
                // The controller is created first with the necessary API Key
                MainController controller = new MainController(apiKey);

                // The view is created next, receiving the controller for delegation
                MainFrame view = new MainFrame(controller);

                // The controller needs a reference back to the view to update it
                controller.setView(view);

                view.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                        "Application failed to start: " + e.getMessage(),
                        "Fatal Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        });
    }
}