package model;

import service.OpenAIService;

/**
 * Singleton class to manage and provide the single instance of OpenAIService.
 * Ensures the API key is handled securely and centrally.
 * This implements the Singleton Design Pattern.
 */
public class APIClient {
    private static APIClient instance;
    private final OpenAIService openAIService;

    /**
     * Private constructor to prevent direct instantiation.
     * @param apiKey The secret key required for API access.
     */
    private APIClient(String apiKey) {
        // Instantiate the service that holds the actual API communication logic
        this.openAIService = new OpenAIService(apiKey);
    }

    /**
     * Provides the global access point to the single instance of APIClient.
     * This method is synchronized for thread safety.
     * @param apiKey The API key (only needed for the first creation).
     * @return The single instance of APIClient.
     */
    public static synchronized APIClient getInstance(String apiKey) {
        if (instance == null) {
            if (apiKey == null || apiKey.isEmpty()) {
                throw new IllegalArgumentException("API Key cannot be null or empty during first initialization.");
            }
            instance = new APIClient(apiKey);
        }
        return instance;
    }

    /**
     * Getter for the OpenAIService instance.
     * @return The service instance used to make API calls.
     */
    public OpenAIService getOpenAIService() {
        return openAIService;
    }
}