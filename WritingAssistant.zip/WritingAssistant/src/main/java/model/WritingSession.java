package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Domain Model representing a single user session for save/load functionality.
 * Implements Serializable to allow saving the session object to a file.
 */
public class WritingSession implements Serializable {
    private static final long serialVersionUID = 1L;

    // Inner class to store a single prompt/response exchange
    public static class Exchange implements Serializable {
        private static final long serialVersionUID = 1L;
        private String input; // Changed from 'prompt' to 'input'
        private String output; // Changed from 'response' to 'output'

        public Exchange(String input, String output) {
            this.input = input;
            this.output = output;
        }

        // FIX: Renamed getPrompt to getInput
        public String getInput() { return input; }

        // FIX: Renamed getResponse to getOutput
        public String getOutput() { return output; }
    }

    // FIX: Renamed 'history' to 'exchanges' to match controller
    private final List<Exchange> exchanges = new ArrayList<>();
    private String title = "New Session";

    /**
     * Adds a new prompt and its corresponding AI response to the session history.
     */
    public void addExchange(String input, String output) {
        // Updated to use 'input' and 'output' to match controller method signature
        exchanges.add(new Exchange(input, output));
    }

    // FIX: Renamed getHistory to getExchanges
    public List<Exchange> getExchanges() {
        return Collections.unmodifiableList(exchanges); // Use unmodifiableList for safe access
    }

    /**
     * FIX: Added missing method required by MainController to display the latest conversation.
     */
    public Exchange getLastExchange() {
        if (exchanges.isEmpty()) {
            return null;
        }
        return exchanges.get(exchanges.size() - 1);
    }

    // Remaining methods (getHistory, setTitle, toString) are fine, just updated field names.

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Session Title: " + title + "\n");
        for (Exchange exchange : exchanges) {
            sb.append("Prompt: ").append(exchange.getInput())
                    .append("\nResponse: ").append(exchange.getOutput()).append("\n---\n");
        }
        return sb.toString();
    }
}